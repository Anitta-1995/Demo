import 'package:flutter/material.dart';

class SignInLabel extends StatelessWidget {
  const SignInLabel({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(child: _buildLabel('Sign In'));
  }
}

class OtpLabel extends StatelessWidget {
  const OtpLabel({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(child: _buildLabel('OTP'));
  }
}

Widget _buildLabel(String label) {
  return Text(
    label,
    style: new TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
  );
}
